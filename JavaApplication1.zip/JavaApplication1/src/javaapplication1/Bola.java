
import java.util.Scanner;



/**
 *
 * @author ALUNO
 */
public class Bola {
    private String cor;
    
    public Bola(String cor){
        this.cor = cor;
        
    }
    public String getCor(){
        return cor;
    }
    public void setCor(String novaCor){
        cor = novaCor;
    }
    
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        Scanner s= new Scanner(System.in);
        System.out.println("Digite a cor da bola que deseja: ");
        String resposta = sc.nextLine();             
        Bola b1 = new Bola(resposta);
        System.out.println("A cor da bola é:"b1.getCor());
        System.out.println("deseja trocar a cor do objeto? \n Digite 1"+"para sim e 2 para não");
        int resposta2 = s.nextInt();
        if(resposta2 ==1){
            System.out.println("Digite para qual cor deseja trocar");
            resposta = sc.nextLine();
            b1.setCor(resposta);
            System.out.println("A cor da Bola é:" + b1.getCor())
        }
        b1.setCor("Azul:");
        System.out.println(b1.getCor());
        
    }
    

    
}
