/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Scanner;

/**
 *
 * @author ALUNO
 */
public class quadrado {
    private int lado;
    
    public quadrado(int lado){
        this.lado = lado;
        
    }
    public int getLado(){
        return lado;
    }
    
    public void setLado(int novoLado){
        lado = novoLado;
    }
        
     public int calArea(){
         return lado*lado;
     }
        
    
    public static void main(int[]args){
        Scanner sc= new Scanner(System.in);
        System.out.println("Digite o lado ");
        int resposta = sc.nextLine();
        quadrado l1= new quadrado(resposta);
        System.out.println("A area é" l1.calArea());
        
    }
    
}
